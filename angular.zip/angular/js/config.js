'use strict';

jolieAppAdmin
	.config(function ($stateProvider, $urlRouterProvider) {

		$urlRouterProvider.otherwise("/dashboard");

		$stateProvider

			// Home
			.state('login', {
				url: "/login",
				templateUrl: "views/login.html",
			})

			// requireLogin = true for pages that require logged in user
			.state('app', {
				abstract: true,
				template: '<ui-view/>',
				data: {
					requireLogin: true // this property will apply to all children of 'app'
				}
			})

			// Dashboard
			.state('app.dashboard', {
				url: "/dashboard",
				templateUrl: "views/dashboard.html",
			})

	})
