'use strict';

jolieAppAdmin

	// =========================================================================
	// Login Modal Controller
	// =========================================================================

	.controller('LoginModalCtrl', function ($rootScope,$scope,loginService) {

		$scope.user={
			grant_ype: 'password'
		};

		 $scope.login = function () {
			console.log("on submit");

			 $rootScope.isLoading = true;
			 $scope.errorRequest = false;

			 loginService.doLogin({},$scope.user,function(data){
				 console.log(data);

				 $rootScope.isLoading = false;
			 },function(err){
				 console.log(err);
				 $scope.errorRequest = true;
				 $rootScope.isLoading = false;
			 });


		}

	})
;