'use strict';

jolieAppAdmin

	// =========================================================================
	// Login Modal
	// =========================================================================

	.service('loginModal', function ($modal, $sessionStorage) {

		// function assignCurrentUser (user) {
		// 	$sessionStorage.currentUser = user;
		// 	return user;
		// }

		// return function() {
		// 	var instance = $modal.open({
		// 		templateUrl: 'views/loginModal.html',
		// 		controller: 'LoginModalCtrl',
		// 		controllerAs: 'LoginModalCtrl'
		// 	});

		// 	return instance.result.then(assignCurrentUser);
		// };

	})


	// This filter makes the assumption that the input will be in decimal form (i.e. 17% is 0.17).
	.filter('commaToDecimal', function(){
		return function(value) {
			return value ? parseFloat(value).toFixed(2).toString().replace('.', ',') : null;
		};
	});
