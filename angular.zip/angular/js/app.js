'use strict';

// Declare app level module which depends on views, and components
var endpoint = 'http://jolietest.azurewebsites.net';

var jolieAppAdmin = angular.module('jolieAppAdmin', [
    //'angular-loading-bar',
     'ngAnimate',
     'ngResource',
    // 'ngMessages',
    'ngStorage',
    'ui.router',
    'ui.bootstrap',
    // 'oc.lazyLoad',
	// 'angular-storage',
	// 'sticky',
	// 'localytics.directives',
	// 'angular-input-stars',
	//'blockUI',
	//'ui.utils.masks',
//	'ngFileUpload',
	//'ngImgCrop'
]);

// Capturing attempted state changes (for logged pages)
jolieAppAdmin.run(function ($rootScope, $state, loginModal, $sessionStorage) {

	$rootScope.$on('$stateChangeStart', function (event, toState, toParams) {

		if (toState.data && toState.data.requireLogin && typeof $sessionStorage.currentUser === 'undefined') {
			event.preventDefault();
			return $state.go('login');
			// loginModal()
			// 	.then(function () {
			// 		if(!$sessionStorage.currentUser.IsRegistrationCompleted){
			// 			$state.go('app.services');
			// 		} else {
			// 			return $state.go(toState.name, toParams);
			// 		}					
			// 	})
			// 	.catch(function () {
			// 		return $state.go('home');
			// 	});
		}

	});

});