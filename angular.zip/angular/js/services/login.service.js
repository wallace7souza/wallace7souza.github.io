/**
 * Created by wallace on 05/07/2016.
 */



jolieAppAdmin

// =========================================================================
// Login Modal
// =========================================================================

    .service('loginService', function ($resource,$httpParamSerializerJQLike) {

        return $resource(endpoint+'/:action/:param/:value',{},{
            doLogin:{params:{action:'Token'},method:'POST',
                headers : {"Content-Type": "application/x-www-form-urlencoded"},
                transformRequest: function(data) {
                    return $httpParamSerializerJQLike(data);
                }}
        });

    });